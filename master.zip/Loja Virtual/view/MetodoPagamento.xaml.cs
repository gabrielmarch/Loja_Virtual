﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Loja_Virtual.view
{
    public partial class MetodoPagamento : Window
    {
        private bool menuVisivel = true;

        public decimal ValorCompra { get; private set; }

        public MetodoPagamento() : this(0m)
        {
        }

        public MetodoPagamento(decimal valorTotal)
        {
            InitializeComponent();

            ValorCompra = valorTotal;

            ValorCompraTexto.Text = valorTotal.ToString("C2");
        }

        private void buttonMenu_Click(object sender, RoutedEventArgs e)
        {
            menuVisivel = !menuVisivel;

            if (menuVisivel)
            {
                BarraLateral.Visibility = Visibility.Visible;
                ColunaMenu.Width = new GridLength(165);
            }
            else
            {
                BarraLateral.Visibility = Visibility.Collapsed;
                ColunaMenu.Width = new GridLength(0);
            }
        }

        private void BtnIrParaCartao_Click(object sender, RoutedEventArgs e)
        {
            AdicionarCartao tela = new AdicionarCartao();

            tela.Show();
            this.Close();
        }

        private void BtnIrParaBoleto_Click(object sender, RoutedEventArgs e)
        {
            GerarBoleto tela = new GerarBoleto();

            tela.Show();
            this.Close();
        }
    }
}

//